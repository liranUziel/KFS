 // First step create a single partition 
    // format(device);
    // char cmd[256];
    // printLogo();
    // fprintf(stdout, "KFS> ");
    // fscanf(stdin, "%s",cmd);
    // while(strcmp(cmd, "exit") != 0)
    // {
    //     dispatch(cmd);
    //     fprintf(stdout, "KFS> ");
    //     fscanf(stdin, "%s",cmd);
    // } 
    // closeBlockDevice(device);