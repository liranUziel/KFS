#include "./Headers/Terminal.h"



const char *CMD_STR[] = {
    "exit",
    "help"
};

void printKFSLogo(){
    printf("\033[0;31m");
    printf("        ,--.                       \n");
    printf("    ,--/  /|     ,---,.  .--.--.    \n");
    printf(" ,---,': / '   ,'  .' | /  /    '.  \n");
    printf(" :   : '/ /  ,---.'   ||  :  /`. /  \n");
    printf(" |   '   ,   |   |   .';  |  |--`   \n");
    printf(" '   |  /    :   :  :  |  :  ;_     \n");
    printf(" |   ;  ;    :   |  |-, \\  \\    `.  \n");
    printf(" :   '   \\   |   :  ;/|  `----.   \\ \n");
    printf(" |   |    '  |   |   .'  __ \\  \\  | \n");
    printf(" '   : |.  \\ |   :  '   /  /`--'  / \n");
    printf(" |   | '_\\.' |   |  |  '--'.     /  \n");
    printf(" '   : |     |   :  \\    `--'---'   \n");
    printf(" ;   |,'     |   | ,'                \n");
    printf(" '---'       `----'                  \n");
    printf("\033[0;37m");
    printf("Welcome to KFS, ");
    printf("\033[1m");
    printf("Krazy File System\n");
    printf("\033[0m");

}

void printHelp(){
    printf("List of commands:\n");
    printf("exit: Exit the terminal\n");
    printf("help: Print this help message\n");
}

void dispatch(char *cmd){
    if(strcmp(cmd, CMD_STR[CMD_HELP]) == 0){
        printHelp();
    }
    else{
        printf("Unknown command\n");
    }
}

