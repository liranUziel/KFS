#include "./Headers/Partition.h"


int currentPartition = 0;
int FreeSpace = 0;

void printPizzaLogo(){
    //  print the LOGO PIPS in Orange to Yellow and the rest in white
    //  first letters of Pizza Partition System in bold
    /*  
        8888888b.  d8b 8888888b.   .d8888b.  
        888   Y88b Y8P 888   Y88b d88P  Y88b 
        888    888     888    888 Y88b.      
        888   d88P 888 888   d88P  "Y888b.   
        8888888P"  888 8888888P"      "Y88b. 
        888        888 888              "888 
        888        888 888        Y88b  d88P 
        888        888 888         "Y8888P"  
                Pizza Partition System                            
    */
    printf("\033[38;2;255;140;0m8888888b.  d8b 8888888b.   .d8888b.  \n");
    printf("\033[38;2;255;165;0m888   Y88b Y8P 888   Y88b d88P  Y88b \n");
    printf("\033[38;2;255;190;0m888    888     888    888 Y88b.      \n");
    printf("\033[38;2;255;215;0m888   d88P 888 888   d88P  \"Y888b.   \n");
    printf("\033[38;2;255;240;0m8888888P\"  888 8888888P\"      \"Y88b. \n");
    printf("\033[38;2;255;255;0m888        888 888              \"888 \n");
    printf("\033[38;2;255;255;0m888        888 888        Y88b  d88P \n");
    printf("\033[38;2;255;255;0m888        888 888         \"Y8888P\"  \n");
    printf("\033[0m\033[1mP\033[22mizza \033[1mP\033[22martition \033[1mS\033[22mystem\033[0m\n");
}

void displayPartitionMenu(){
    /* dislay the partition menu as follow 
                KFS Partition Menu
    Partion Name                       Size
        



    F - Format  C - Create Partition  
    
    */
    // printPizzaLogo();
    
}

void setPartitionSize(PartitionTable** pt,unsigned int size, int index){
    // set the size of the current partition
    if((*pt)->count > index){
        // check if the size is vali    }else{
        fprintf(stderr, "[setPartitionSize] Error: invalid partition index\n");
    }

}

void updateStart(PartitionTable** pt){
    // update the start of all partitions
    // all partition start need to add sizeof(Partition)

    for(int i = 0; i < (*pt)->count; i++){
        if(i == 0){
            (*pt)->partitions[i].start = sizeof(Partition_HEADER) + sizeof(Partition);
        }else{
            (*pt)->partitions[i].start = (*pt)->partitions[i-1].start + (*pt)->partitions[i-1].size;
        }
    }
 
}

/**
 * @brief Create a Partition Table object
 * 
 * @param pt 
 * @param size 
 * @details Create a Partition Table object with a defualt sinle partition taken the whole disk
 * Note: The size of the defualt partition is  TotalSize - sizeof(FS_HEADER) - sizeof(PartitionTable)
 */

void createPartitionTable(PartitionTable** pt, int size){
    // size is total size of the dick
    /*
        free space = total_size - sizeof(partition_HEADER) - #partition * PTE;
     */
    // size is BLOCK_SIZE as full block
    unsigned int MAX = BLOCK_SIZE - (sizeof(Partition_HEADER) + sizeof(Partition));
    if(size > MAX){
        fprintf(stderr,"[createPartitionTable] Error: invalid initial partition size\n");
        return;
    }else{
    }
    fprintf(stdout,"Creating Partition Table\n");
    (*pt) = (PartitionTable*)malloc(sizeof(PartitionTable));
    fprintf(stdout,"Creating Partition C\n");
    (*pt)->partitions = (Partition*)malloc(sizeof(Partition));
    (*pt)->size = 1;
    (*pt)->count = 1;
    (*pt)->partitions[0].name[0] = 'C';
    (*pt)->partitions[0].name[1] = '\0';
    (*pt)->partitions[0].size = size;
    (*pt)->partitions[0].start = sizeof(Partition_HEADER) + sizeof(Partition);
    FreeSpace = MAX - size;
    //Create KFS and write KFS table to start of the partition
}

Partition createPartition(PartitionTable pt,unsigned int size){
    // get the last partition name and increment it
    char letter = pt.partitions[pt.count-1].name[0];
    unsigned int prevAddr = pt.partitions[pt.count-1].start;
    unsigned int prevSize = pt.partitions[pt.count-1].size;

    if(letter < 'Z'){
        letter++; 
    }else{
        letter = 'a';
    }
    Partition p;
    p.size = size;
    p.start = 0;
    p.name[0] = letter;
    p.name[1] = '\0';
    p.start = prevAddr + prevSize;
    return p;
}

void addPartition(PartitionTable** pt, unsigned int size){
    //check if free space is available
    if(FreeSpace < size){
        fprintf(stderr, "[addPartition] Error: not enough free space\n");
        return;
    }
    if((*pt)->count <= (*pt)->size){
        (*pt)->size *= 2;
        (*pt)->partitions = (Partition*)realloc((*pt)->partitions, sizeof(Partition) * ((*pt)->size));
    }
    // get free space on the disk
    Partition p = createPartition(*(*pt), 1024);
    fprintf(stdout,"Creating Partition %s\n", p.name);
    // need to update the start of all previous partitions
    updateStart(pt);
    (*pt)->partitions[(*pt)->count] = p;
    (*pt)->count++;
}
void printPartitionTable(PartitionTable* pt){
    for(int i = 0; i < pt->count; i++){
        printf("Partition Name: %s Addr:0x%.5x Size:%d\n", pt->partitions[i].name, pt->partitions[i].start, pt->partitions[i].size);
    }
}
    
void writePartitionTable(BlockDevice* device, PartitionTable* pt){
    Partition_HEADER header;
    strcpy(header.magic, "PiPs");
    strcpy(header.name, "Pizza");
    header.version = 1;
    header.size = sizeof(Partition) * pt->count;

    writeBlockDevice(device, 0, sizeof(header), (char*)&header);
    writeBlockDevice(device, sizeof(header), header.size, (char*)pt->partitions);
}

void readPartitionTable(BlockDevice* device, PartitionTable** pt){
    Partition_HEADER header;
    readBlockDevice(device, 0, sizeof(header), (char*)&header);

    if(strcmp(header.magic, "PiPs") != 0){
        fprintf(stdout,"Initializing PiPs...\n");
        return;
    }

    *pt = (PartitionTable*)malloc(sizeof(PartitionTable));
    (*pt)->partitions = (Partition*)malloc(header.size);
    (*pt)->size = header.size / sizeof(Partition);
    (*pt)->count = (*pt)->size;
    
    readBlockDevice(device, sizeof(header), header.size, (char*)(*pt)->partitions);
    currentPartition = 0;

}